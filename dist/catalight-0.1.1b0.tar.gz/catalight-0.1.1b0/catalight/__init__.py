"""Python package for automation of photocatalysis experiment and analysis."""
