"""
Contains GC resources and code.

Contains resources (manuals, calibration files, etc.) and code for connecting
with equipment. This directory also holds SRI Peaksimpleconnector software.

Created on Mon Jan 16 16:29:11 2023
@author: Briley Bourgeois
"""
